﻿import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from main import app, Base, User, Product, db

test_engine=create_engine("sqlite://",connect_args={"check_same_thread":False},poolclass=StaticPool)
TestSession=sessionmaker(bind=test_engine,autoflush=False,autocommit=False)

def override_db():
    s=TestSession()
    try: yield s
    finally: s.close()

app.dependency_overrides[db]=override_db
client=TestClient(app)

@pytest.fixture(autouse=True)
def reset_db():
    Base.metadata.drop_all(test_engine); Base.metadata.create_all(test_engine)
    yield
    Base.metadata.drop_all(test_engine)

def register(email="u@example.com",password="password123"):
    return client.post("/auth/register",json={"email":email,"password":password})

def test_registration_and_duplicate():
    assert register().status_code==201
    assert register().status_code==400

def test_login_and_invalid_login():
    register()
    assert client.post("/auth/login",json={"email":"u@example.com","password":"password123"}).status_code==200
    assert client.post("/auth/login",json={"email":"u@example.com","password":"incorrect123"}).status_code==401

def test_unauthorized_profile():
    assert client.get("/users/me").status_code==401

def test_product_create_requires_admin():
    assert client.post("/products",json={"name":"Book","price":10}).status_code==401

def test_product_listing_pagination():
    s=TestSession()
    s.add_all([Product(name=f"Product {i}",price=5) for i in range(12)]); s.commit(); s.close()
    r=client.get("/products?page=2&limit=5")
    assert r.status_code==200 and len(r.json()["items"])==5
    assert r.json()["total"]==12 and r.json()["total_pages"]==3

def test_product_search():
    s=TestSession(); s.add(Product(name="Python Guide",price=10)); s.commit(); s.close()
    assert client.get("/products?search=python").json()["total"]==1

def test_cart_operations():
    token=register().json()["token"]; headers={"Authorization":f"Bearer {token}"}
    s=TestSession(); s.add(Product(id=1,name="Book",price=10)); s.commit(); s.close()
    assert client.post("/cart/items",json={"product_id":1,"quantity":2},headers=headers).json()["total"]==20
    assert client.delete("/cart/items/1",headers=headers).json()["total"]==0

def test_empty_checkout_fails():
    token=register().json()["token"]
    assert client.post("/payments/create-checkout-session",headers={"Authorization":f"Bearer {token}"}).status_code==400

def test_other_user_cannot_read_order():
    token=register().json()["token"]
    s=TestSession(); u=s.query(User).first()
    from main import Order
    s.add(Order(user_id=u.id,total=3)); s.commit(); s.close()
    other=register("other@example.com").json()["token"]
    assert client.get("/orders/1",headers={"Authorization":f"Bearer {other}"}).status_code==403

