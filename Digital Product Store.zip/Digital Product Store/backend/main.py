﻿import os
from datetime import datetime, timedelta
from typing import Optional
import stripe
from fastapi import FastAPI, Depends, HTTPException, Header, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer
from jose import jwt, JWTError
from passlib.context import CryptContext
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import create_engine, Column, Integer, String, Float, Boolean, ForeignKey, DateTime, func
from sqlalchemy.orm import declarative_base, relationship, sessionmaker, Session

DATABASE_URL=os.getenv("DATABASE_URL","sqlite:///./store.db")
engine=create_engine(DATABASE_URL,connect_args={"check_same_thread":False} if DATABASE_URL.startswith("sqlite") else {})
SessionLocal=sessionmaker(bind=engine,autoflush=False,autocommit=False)
Base=declarative_base(); SECRET=os.getenv("JWT_SECRET","change-this-secret"); ALGORITHM="HS256"
pwd=CryptContext(schemes=["pbkdf2_sha256"],deprecated="auto"); oauth=OAuth2PasswordBearer(tokenUrl="/auth/login")
stripe.api_key=os.getenv("STRIPE_SECRET_KEY","")

class User(Base):
 __tablename__="users"; id=Column(Integer,primary_key=True);
 email=Column(String,unique=True,index=True,nullable=False); 
 password=Column(String,nullable=False); 
 is_admin=Column(Boolean,default=False); 
 cart=relationship("Cart",back_populates="user",uselist=False,cascade="all,delete-orphan"); 
 orders=relationship("Order",back_populates="user")
 
class Product(Base):
 __tablename__="products";
 id=Column(Integer,primary_key=True);
 name=Column(String,nullable=False);
 description=Column(String,default="");
 price=Column(Float,nullable=False);
 active=Column(Boolean,default=True)
 
class Cart(Base):
 __tablename__="carts";
 id=Column(Integer,primary_key=True);
 user_id=Column(Integer,ForeignKey("users.id"),unique=True);
 user=relationship("User",back_populates="cart");
 items=relationship("CartItem",cascade="all,delete-orphan")
 
class CartItem(Base):
 __tablename__="cart_items"; 
 id=Column(Integer,primary_key=True); 
 cart_id=Column(Integer,ForeignKey("carts.id")); 
 product_id=Column(Integer,ForeignKey("products.id")); 
 quantity=Column(Integer,nullable=False);
 product=relationship("Product")
 
class Order(Base):
 __tablename__="orders";
 id=Column(Integer,primary_key=True); 
 user_id=Column(Integer,ForeignKey("users.id"));
 status=Column(String,default="PENDING"); 
 total=Column(Float,nullable=False);
 created_at=Column(DateTime,default=datetime.utcnow);
 stripe_session=Column(String); 
 user=relationship("User",back_populates="orders")
 items=relationship("OrderItem",cascade="all,delete-orphan"); 
 payment=relationship("Payment",back_populates="order",uselist=False,cascade="all,delete-orphan")
 
class OrderItem(Base):
 __tablename__="order_items";
 id=Column(Integer,primary_key=True);
 order_id=Column(Integer,ForeignKey("orders.id"));
 product_id=Column(Integer,ForeignKey("products.id"));
 name=Column(String);
 unit_price=Column(Float);
 quantity=Column(Integer)
 
class Payment(Base):
 __tablename__="payments";
 id=Column(Integer,primary_key=True);
 order_id=Column(Integer,ForeignKey("orders.id"),unique=True);
 status=Column(String,default="PENDING");
 stripe_session=Column(String);
 order=relationship("Order",back_populates="payment")
Base.metadata.create_all(engine)
app=FastAPI(title="Digital Product Store API")
app.add_middleware(CORSMiddleware,allow_origins=os.getenv("FRONTEND_URL","http://localhost:5173").split(","),allow_methods=["*"],allow_headers=["*"])

def db():
 s=SessionLocal()
 try: yield s
 finally: s.close()
def token_for(u): return jwt.encode({"sub":str(u.id),"exp":datetime.utcnow()+timedelta(hours=24)},SECRET,algorithm=ALGORITHM)
def current_user(token:str=Depends(oauth),s:Session=Depends(db)):
 try: uid=int(jwt.decode(token,SECRET,algorithms=[ALGORITHM])["sub"])
 except Exception: raise HTTPException(401,"Invalid or expired token")
 u=s.get(User,uid)
 if not u: raise HTTPException(401,"User not found")
 return u
def admin(u=Depends(current_user)):
 if not u.is_admin: raise HTTPException(403,"Admin access required")
 return u
def cart_for(u,s):
 c=s.query(Cart).filter_by(user_id=u.id).first()
 if not c: c=Cart(user_id=u.id); s.add(c); s.commit(); s.refresh(c)
 return c
def cart_json(c):
 items=[{"product_id":i.product_id,"name":i.product.name,"price":i.product.price,"quantity":i.quantity,"subtotal":round(i.product.price*i.quantity,2)} for i in c.items]
 return {"items":items,"total":round(sum(x["subtotal"] for x in items),2)}
class Credentials(BaseModel): email:EmailStr; password:str=Field(min_length=8)
class ProductIn(BaseModel): name:str=Field(min_length=1); description:str=""; price:float=Field(gt=0)
class CartIn(BaseModel): product_id:int; quantity:int=Field(gt=0)

@app.get("/health")
def health(): return {"status":"ok"}
@app.post("/auth/register",status_code=201)
def register(d:Credentials,s:Session=Depends(db)):
 if s.query(User).filter_by(email=d.email).first(): raise HTTPException(400,"Email already registered")
 u=User(email=d.email,password=pwd.hash(d.password)); s.add(u); s.commit(); s.refresh(u); s.add(Cart(user_id=u.id)); s.commit()
 return {"token":token_for(u),"user":{"id":u.id,"email":u.email,"is_admin":u.is_admin}}
@app.post("/auth/login")
def login(d:Credentials,s:Session=Depends(db)):
 u=s.query(User).filter_by(email=d.email).first()
 if not u or not pwd.verify(d.password,u.password): raise HTTPException(401,"Invalid credentials")
 return {"token":token_for(u),"user":{"id":u.id,"email":u.email,"is_admin":u.is_admin}}
@app.get("/users/me")
def profile(u=Depends(current_user)): return {"id":u.id,"email":u.email,"is_admin":u.is_admin}
@app.get("/products")
def products(page:int=Query(1,ge=1),limit:int=Query(10,ge=1,le=100),search:str="",s:Session=Depends(db)):
 q=s.query(Product).filter_by(active=True)
 if search: q=q.filter(Product.name.ilike(f"%{search}%"))
 n=q.count(); return {"items":[{"id":p.id,"name":p.name,"description":p.description,"price":p.price} for p in q.order_by(Product.id).offset((page-1)*limit).limit(limit)],"page":page,"limit":limit,"total":n,"total_pages":(n+limit-1)//limit}
@app.get("/products/{pid}")
def product(pid:int,s:Session=Depends(db)):
 p=s.get(Product,pid)
 if not p or not p.active: raise HTTPException(404,"Product not found")
 return {"id":p.id,"name":p.name,"description":p.description,"price":p.price}
@app.post("/products",status_code=201)
def create_product(d:ProductIn,s:Session=Depends(db),_=Depends(admin)):
 p=Product(**d.model_dump()); s.add(p); s.commit(); s.refresh(p); return {"id":p.id,"name":p.name,"description":p.description,"price":p.price}
@app.put("/products/{pid}")
def update_product(pid:int,d:ProductIn,s:Session=Depends(db),_=Depends(admin)):
 p=s.get(Product,pid)
 if not p: raise HTTPException(404,"Product not found")
 for k,v in d.model_dump().items(): setattr(p,k,v)
 s.commit(); return {"id":p.id,"name":p.name,"description":p.description,"price":p.price}
@app.delete("/products/{pid}",status_code=204)
def delete_product(pid:int,s:Session=Depends(db),_=Depends(admin)):
 p=s.get(Product,pid)
 if not p: raise HTTPException(404,"Product not found")
 p.active=False; s.commit()
@app.get("/cart")
def get_cart(u=Depends(current_user),s:Session=Depends(db)): return cart_json(cart_for(u,s))
@app.post("/cart/items")
def add_cart(d:CartIn,u=Depends(current_user),s:Session=Depends(db)):
 p=s.get(Product,d.product_id)
 if not p or not p.active: raise HTTPException(404,"Product not found")
 c=cart_for(u,s); i=next((x for x in c.items if x.product_id==p.id),None)
 if i: i.quantity+=d.quantity
 else: c.items.append(CartItem(product_id=p.id,quantity=d.quantity))
 s.commit(); return cart_json(c)
@app.put("/cart/items/{pid}")
def update_cart(pid:int,quantity:int=Query(...,gt=0),u=Depends(current_user),s:Session=Depends(db)):
 c=cart_for(u,s); i=next((x for x in c.items if x.product_id==pid),None)
 if not i: raise HTTPException(404,"Cart item not found")
 i.quantity=quantity; s.commit(); return cart_json(c)
@app.delete("/cart/items/{pid}")
def remove_cart(pid:int,u=Depends(current_user),s:Session=Depends(db)):
 c=cart_for(u,s); i=next((x for x in c.items if x.product_id==pid),None)
 if not i: raise HTTPException(404,"Cart item not found")
 s.delete(i); s.commit(); return cart_json(c)
@app.delete("/cart")
def clear_cart(u=Depends(current_user),s:Session=Depends(db)):
 c=cart_for(u,s); c.items.clear(); s.commit(); return {"items":[],"total":0}
@app.post("/payments/create-checkout-session")
def checkout(u=Depends(current_user),s:Session=Depends(db)):
 c=cart_for(u,s)
 if not c.items: raise HTTPException(400,"Cart is empty")
 if not stripe.api_key: raise HTTPException(503,"Set STRIPE_SECRET_KEY to enable checkout")
 o=Order(user_id=u.id,total=sum(i.product.price*i.quantity for i in c.items),status="PENDING")
 for i in c.items: o.items.append(OrderItem(product_id=i.product_id,name=i.product.name,unit_price=i.product.price,quantity=i.quantity))
 s.add(o); s.commit(); s.refresh(o)
 try:
  session=stripe.checkout.Session.create(mode="payment",line_items=[{"price_data":{"currency":"usd","product_data":{"name":i.product.name},"unit_amount":round(i.product.price*100)},"quantity":i.quantity} for i in c.items],success_url=os.getenv("PAYMENT_SUCCESS_URL","http://localhost:5173/orders?success=1"),cancel_url=os.getenv("PAYMENT_CANCEL_URL","http://localhost:5173/cart?cancelled=1"),metadata={"order_id":str(o.id)})
  o.stripe_session=session.id; o.payment=Payment(status="PENDING",stripe_session=session.id); s.commit()
  return {"checkout_url":session.url,"order_id":o.id}
 except Exception as e:
  o.status="FAILED"; s.commit(); raise HTTPException(502,"Stripe checkout failed")
@app.post("/payments/webhook")
async def webhook(payload:bytes,stripe_signature:Optional[str]=Header(None,alias="Stripe-Signature"),s:Session=Depends(db)):
 secret=os.getenv("STRIPE_WEBHOOK_SECRET","")
 if not stripe_signature or not secret: raise HTTPException(400,"Webhook signature or secret missing")
 try: event=stripe.Webhook.construct_event(payload,stripe_signature,secret)
 except Exception: raise HTTPException(400,"Invalid webhook signature or payload")
 kinds=("checkout.session.completed","checkout.session.async_payment_succeeded","checkout.session.async_payment_failed","checkout.session.expired")
 if event["type"] in kinds:
  obj=event["data"]["object"]; oid=(obj.get("metadata") or {}).get("order_id"); o=s.get(Order,int(oid)) if oid else None
  if o:
   o.status="PAID" if event["type"] in kinds[:2] else ("FAILED" if event["type"]==kinds[2] else "CANCELLED")
   if o.payment: o.payment.status=o.status
   if o.status=="PAID":
    c=s.query(Cart).filter_by(user_id=o.user_id).first()
    if c: c.items.clear()
   s.commit()
 return {"received":True}
@app.get("/orders")
def orders(page:int=Query(1,ge=1),limit:int=Query(10,ge=1,le=100),u=Depends(current_user),s:Session=Depends(db)):
 q=s.query(Order).filter_by(user_id=u.id); n=q.count()
 return {"items":[{"id":o.id,"status":o.status,"total":o.total,"created_at":o.created_at,"payment_status":o.payment.status if o.payment else o.status} for o in q.order_by(Order.id.desc()).offset((page-1)*limit).limit(limit)],"page":page,"limit":limit,"total":n,"total_pages":(n+limit-1)//limit}
@app.get("/orders/{oid}")
def order_detail(oid:int,u=Depends(current_user),s:Session=Depends(db)):
 o=s.get(Order,oid)
 if not o: raise HTTPException(404,"Order not found")
 if o.user_id!=u.id and not u.is_admin: raise HTTPException(403,"Not your order")
 return {"id":o.id,"status":o.status,"total":o.total,"payment_status":o.payment.status if o.payment else o.status,"items":[{"name":i.name,"unit_price":i.unit_price,"quantity":i.quantity} for i in o.items]}
@app.get("/admin/orders")
def admin_orders(page:int=Query(1,ge=1),limit:int=Query(10,ge=1,le=100),s:Session=Depends(db),_=Depends(admin)):
 q=s.query(Order); n=q.count()
 return {"items":[{"id":o.id,"user_id":o.user_id,"status":o.status,"total":o.total} for o in q.order_by(Order.id.desc()).offset((page-1)*limit).limit(limit)],"page":page,"limit":limit,"total":n,"total_pages":(n+limit-1)//limit}
@app.get("/admin/stats")
def stats(s:Session=Depends(db),_=Depends(admin)):
 return {"total_products":s.query(Product).filter_by(active=True).count(),"total_orders":s.query(Order).count(),"paid_orders":s.query(Order).filter_by(status="PAID").count(),"total_revenue":s.query(func.coalesce(func.sum(Order.total),0)).filter_by(status="PAID").scalar()}
@app.get("/reports/most-purchased")
def most_purchased(s:Session=Depends(db),_=Depends(admin)):
 rows=s.query(OrderItem.name,func.sum(OrderItem.quantity)).join(Order).filter(Order.status=="PAID").group_by(OrderItem.name).order_by(func.sum(OrderItem.quantity).desc()).limit(10).all()
 return [{"product":name,"quantity":qty} for name,qty in rows]
@app.get("/reports/never-purchased")
def never_purchased(s:Session=Depends(db),_=Depends(admin)):
 bought=s.query(OrderItem.product_id).join(Order).filter(Order.status=="PAID").subquery()
 return [{"id":p.id,"name":p.name} for p in s.query(Product).filter(~Product.id.in_(bought))]




