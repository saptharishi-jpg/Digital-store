﻿# Digital Product Store

A small full-stack digital download storefront. The backend uses FastAPI, SQLAlchemy and SQLite by default. The frontend is React + Vite. Stripe Checkout is enabled when test keys are configured.

## Requirements

Python 3.10+, Node.js 18+, npm, and (for payments) a Stripe account in test mode plus Stripe CLI for local webhooks.

## Setup

1. Create a virtual environment and install backend dependencies:

   ```powershell
   cd backend
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   Copy-Item .env.example .env
   ```

2. Set `JWT_SECRET`, `STRIPE_SECRET_KEY`, and `STRIPE_WEBHOOK_SECRET` in backend/.env. Start uvicorn with `--env-file .env` so it loads those values. The app defaults to SQLite at backend/store.db. For PostgreSQL, install psycopg and set `DATABASE_URL=postgresql+psycopg://user:password@localhost/store`.

3. Start the API from the backend directory:

   ```powershell
   uvicorn main:app --reload --env-file .env
   ```

   Interactive Swagger docs: http://localhost:8000/docs

4. In another terminal, run the frontend:

   ```powershell
   cd frontend
   npm install
   npm run dev
   ```

   Open http://localhost:5173. Set `VITE_API_URL` if the API is hosted elsewhere.

## Admin access

Registration creates regular users. To promote a user, use a Python shell from backend after registration:

```powershell
py -c "from main import SessionLocal,User; s=SessionLocal(); u=s.query(User).filter_by(email='you@example.com').one(); u.is_admin=True; s.commit(); s.close()"
```

Then log in again and open /admin/products. Admin routes provide product CRUD, orders, and sales statistics.

## Stripe test checkout

Use a Stripe test secret key (sk_test_...) in the backend environment. Start a local webhook forwarder:

```powershell
stripe listen --forward-to localhost:8000/payments/webhook
```

Copy the printed whsec_... signing secret to `STRIPE_WEBHOOK_SECRET`, then restart the backend. Checkout redirects the customer to Stripe. The verified webhook sets PAID, FAILED, or CANCELLED; the return page itself never marks an order paid. Use Stripe test card 4242 4242 4242 4242 with any future expiry and CVC. For evidence, capture the Stripe-hosted test checkout and the resulting PAID status in /orders after webhook delivery.

## API overview

- Auth: POST /auth/register, POST /auth/login, GET /users/me
- Products: GET /products?page=1&limit=10&search=python, GET /products/{id}; admin POST/PUT/DELETE /products
- Cart: GET /cart, POST /cart/items, PUT/DELETE /cart/items/{product_id}, DELETE /cart
- Checkout and signed webhook: POST /payments/create-checkout-session, POST /payments/webhook
- Orders: GET /orders?page=1&limit=5, GET /orders/{id}; admin GET /admin/orders
- Admin sales: GET /admin/stats, /reports/most-purchased, /reports/never-purchased

Bearer token required for profile, cart, and orders; admin role required for product writes and reporting. Currency is USD and product price values are dollars. Database tables are created automatically when the API starts.

## Tests

From backend directory:

```powershell
pytest -q
```

The tests use an isolated local SQL database, covering duplicate registration, login, unauthorized APIs, product listing/search/pagination, cart operations, empty checkout, and order ownership. Stripe network checkout is not called in the test suite.


